function showMessage()
{
    alert('Welkom bij de Formule 1 fanpagina!');
} 

window.onload = showMessage;

function changeBackground(color)

{
    document.body.style.backgroundColor=color;
} 

function changeTextColor(color)

{
    document.querySelector('h1').style.color=color;
}