let randNumber = Math.floor(Math.random() * 100) + 1;
let amount = 0

console.log(randNumber);

function resetNumber()
{
    const atempts = document.getElementById('feedback') 
    randNumber = Math.floor(Math.random()* 100) + 1;
    console.log(randNumber);
    let answer= document.getElementById('guessField').value;
    console.log(answer);
    amount = 0
    atempts.innerHTML = "Aantal Pogingen: " + amount
}

function checkNumber()
{
    let answer= document.getElementById('guessField').value;
    const atempts = document.getElementById('feedback')
    
    console.log(answer);
    if (answer < randNumber) 
        {
            document.getElementById('reply').innerHTML = "Te laag!";
            amount += 1
            atempts.innerHTML = "Aantal Pogingen: " + amount
            reply.style.color = "red"
        }
    else if (answer > randNumber)
        {
            document.getElementById('reply').innerHTML = "Te hoog!";
            amount += 1
            atempts.innerHTML = "Aantal Pogingen: " + amount
            reply.style.color = "red"
        }
    else if (answer === answer)
        {
            document.getElementById('reply').innerHTML= "Juist! Je hebt hem geraad."
            reply.style.color = "lightgreen"
            amount += 1
            atempts.innerHTML = "Aantal Pogingen: " + amount
        }
    
}


