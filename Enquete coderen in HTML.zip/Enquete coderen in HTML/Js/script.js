function colorInvert() 
{
   var element = document.body;
   element.classList.toggle("colorInvert");
}