function generateBoard() {
const rows = parseInt(document.getElementById("rows").value);
const cols= parseInt(document.getElementById("cols").value);

const canvas = document.getElementById("chessboard");    
const context = canvas.getContext("2d");

const blocks = Math.min(canvas.width/ cols, canvas.height / rows);

context.clearRect(0, 0, canvas.width, canvas.height)

for (let row = 0; row < rows; row++) {
    for (let col = 0; col < cols; col++) {
        context.fillStyle = (row + col) % 2 === 0 ? '#444' : '#eee';
        context.fillRect(col * blocks, row * blocks, blocks, blocks);
        }
    }
}