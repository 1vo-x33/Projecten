
const canvas = document.getElementById("board");
const ctx = canvas.getContext('2d');
let choiceC = 0;
let choiceS = 0;

function getColour() {
choiceC = document.getElementById("input").value;
   
switch(choiceC){
    case "1":
        ctx.fillStyle = "red";
        console.log("colour is red");
        break;
    case "2":
        ctx.fillStyle = "yellow";
        break;
    case "3" :
        ctx.fillStyle = "green";
        break;
    case '4':
        ctx.fillStyle = "pink";
        console.log("colour is pink");
        break;
    case '5':
        ctx.fillStyle = "blue";
        break;
    default:
        alert('U no no choose');
    }        
}
function chooseShape(choiceS){
    choiceS = document.getElementById("shape").value;

    switch(choiceS){
        case '1': // Square
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillRect(0, 0, canvas.width, canvas.height);
        break;

        case '2': // Circle
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.beginPath();
            ctx.arc(200, 200, 200, 0, 20 * Math.PI);   
            ctx.fill();
        break;

        case '3': //Triangle
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.beginPath();
            ctx.moveTo(canvas.width / 2, 0); 
            ctx.lineTo(canvas.width, canvas.height);
            ctx.lineTo(0, canvas.height);
            ctx.closePath();
            ctx.fill();
        break;

        default:
            alert('You did not choose a valid shape.');
    }
}
    

    